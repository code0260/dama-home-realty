function _nullishReceiverError(r) {
  throw new TypeError("Cannot set property of null or undefined.");
}
export { _nullishReceiverError as default };