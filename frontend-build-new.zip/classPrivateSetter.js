import assertClassBrand from "./assertClassBrand.js";
function _classPrivateSetter(s, r, a, t) {
  return r(assertClassBrand(s, a), t), t;
}
export { _classPrivateSetter as default };