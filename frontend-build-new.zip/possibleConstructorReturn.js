import _typeof from "./typeof.js";
import assertThisInitialized from "./assertThisInitialized.js";
function _possibleConstructorReturn(t, e) {
  if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;
  if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
  return assertThisInitialized(t);
}
export { _possibleConstructorReturn as default };