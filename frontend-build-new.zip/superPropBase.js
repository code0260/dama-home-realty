import getPrototypeOf from "./getPrototypeOf.js";
function _superPropBase(t, o) {
  for (; !{}.hasOwnProperty.call(t, o) && null !== (t = getPrototypeOf(t)););
  return t;
}
export { _superPropBase as default };