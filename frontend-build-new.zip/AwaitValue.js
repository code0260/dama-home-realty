function _AwaitValue(t) {
  this.wrapped = t;
}
export { _AwaitValue as default };