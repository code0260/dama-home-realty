import assertClassBrand from "./assertClassBrand.js";
function _classPrivateGetter(s, r, a) {
  return a(assertClassBrand(s, r));
}
export { _classPrivateGetter as default };