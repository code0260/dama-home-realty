import arrayLikeToArray from "./arrayLikeToArray.js";
function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return arrayLikeToArray(r);
}
export { _arrayWithoutHoles as default };