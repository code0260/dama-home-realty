function _interopRequireDefault(e) {
  return e && e.__esModule ? e : {
    "default": e
  };
}
export { _interopRequireDefault as default };