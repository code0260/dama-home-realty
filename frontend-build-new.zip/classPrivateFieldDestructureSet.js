import classApplyDescriptorDestructureSet from "./classApplyDescriptorDestructureSet.js";
import classPrivateFieldGet2 from "./classPrivateFieldGet2.js";
function _classPrivateFieldDestructureSet(e, t) {
  var r = classPrivateFieldGet2(t, e);
  return classApplyDescriptorDestructureSet(e, r);
}
export { _classPrivateFieldDestructureSet as default };