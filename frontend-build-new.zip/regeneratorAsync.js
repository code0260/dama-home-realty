import regeneratorAsyncGen from "./regeneratorAsyncGen.js";
function _regeneratorAsync(n, e, r, t, o) {
  var a = regeneratorAsyncGen(n, e, r, t, o);
  return a.next().then(function (n) {
    return n.done ? n.value : a.next();
  });
}
export { _regeneratorAsync as default };