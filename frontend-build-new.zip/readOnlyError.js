function _readOnlyError(r) {
  throw new TypeError('"' + r + '" is read-only');
}
export { _readOnlyError as default };