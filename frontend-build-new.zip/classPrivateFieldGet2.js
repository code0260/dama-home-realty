import assertClassBrand from "./assertClassBrand.js";
function _classPrivateFieldGet2(s, a) {
  return s.get(assertClassBrand(s, a));
}
export { _classPrivateFieldGet2 as default };