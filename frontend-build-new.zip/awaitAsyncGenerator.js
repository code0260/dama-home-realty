import OverloadYield from "./OverloadYield.js";
function _awaitAsyncGenerator(e) {
  return new OverloadYield(e, 0);
}
export { _awaitAsyncGenerator as default };