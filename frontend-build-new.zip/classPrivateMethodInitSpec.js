import checkPrivateRedeclaration from "./checkPrivateRedeclaration.js";
function _classPrivateMethodInitSpec(e, a) {
  checkPrivateRedeclaration(e, a), a.add(e);
}
export { _classPrivateMethodInitSpec as default };