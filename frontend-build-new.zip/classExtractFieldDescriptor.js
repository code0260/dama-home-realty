import classPrivateFieldGet2 from "./classPrivateFieldGet2.js";
function _classExtractFieldDescriptor(e, t) {
  return classPrivateFieldGet2(t, e);
}
export { _classExtractFieldDescriptor as default };