import classApplyDescriptorGet from "./classApplyDescriptorGet.js";
import classPrivateFieldGet2 from "./classPrivateFieldGet2.js";
function _classPrivateFieldGet(e, t) {
  var r = classPrivateFieldGet2(t, e);
  return classApplyDescriptorGet(e, r);
}
export { _classPrivateFieldGet as default };